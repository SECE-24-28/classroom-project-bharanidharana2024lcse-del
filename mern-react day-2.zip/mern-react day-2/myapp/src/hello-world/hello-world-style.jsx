import React from 'react';

import styled from 'styled-components'
export const FormContainer = styled.div`
  background-color: #529ddeff;
  border: 2px solid #4caf50;
    border-radius: 10px;
    padding: 20px;
    `;
import React from 'react';

const HelloWorldComponent = () => {
  return (
    <>
      <div>
        <h2>Hello, Everyone!</h2>
        <p>Welcome to my first React component.</p>
      </div>
      
    </>
  );
};

export default HelloWorldComponent;
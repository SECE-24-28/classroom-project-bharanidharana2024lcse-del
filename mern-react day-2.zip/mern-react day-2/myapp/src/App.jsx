import "./App.css";
import FormComponent from "./form/form-component.jsx";

function App() {
  return (
    // <FormComponent/>
    <SymbolComponent />
  );
}

export default App;
